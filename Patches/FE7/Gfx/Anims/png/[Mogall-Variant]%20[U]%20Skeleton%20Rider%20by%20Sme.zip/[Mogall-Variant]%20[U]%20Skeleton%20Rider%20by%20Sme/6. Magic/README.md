# [\[Mogall-Variant\] \[U\] Skeleton Rider by Sme](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FMonsters%20-%20Basic%20Types%2F%5BMogall-Variant%5D%20%5BU%5D%20Skeleton%20Rider%20by%20Sme%2F6.%20Magic)

## Magic

| Still | Animation |
| :---: | :-------: |
| ![Magic still](./Magic_000.png) | ![Magic](./Magic.gif) |

## Credit

Made by Sme.
