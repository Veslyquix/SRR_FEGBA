# [\[Black Hole\] Infantry {Amyd, Dark}](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FAdvance%20Wars%20Animation%20Ports%2F%5BBlack%20Hole%5D%20Infantry%20%7BAmyd%2C%20Dark%7D%2F5.%20Bow%20(Gun))

## Bow

| Still | Animation |
| :---: | :-------: |
| ![Bow still](./Bow_000.png) | ![Bow](./Bow.gif) |

## Credit

- Sprites By {Amyd}

- Coding and Formatting by Dark. (Kurwa Dark!)
