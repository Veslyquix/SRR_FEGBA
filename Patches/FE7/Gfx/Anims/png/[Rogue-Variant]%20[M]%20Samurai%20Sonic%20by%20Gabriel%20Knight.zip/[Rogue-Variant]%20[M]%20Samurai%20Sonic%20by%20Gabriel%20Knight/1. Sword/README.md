# [\[Rogue-Variant\] \[M\] Samurai Sonic by Gabriel Knight](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FInfantry%20-%20(Swd)%20Myrms%20and%20Swordmasters%2F%5BRogue-Variant%5D%20%5BM%5D%20Samurai%20Sonic%20by%20Gabriel%20Knight%2F1.%20Sword)

## Sword

| Still | Animation |
| :---: | :-------: |
| ![Sword still](./Sword_000.png) | ![Sword](./Sword.gif) |

## Credit

Animation by Gabriel Knight

Script and format by 7743.
