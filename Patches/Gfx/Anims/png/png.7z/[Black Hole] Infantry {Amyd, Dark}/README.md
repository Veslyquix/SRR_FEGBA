# [\[Black Hole\] Infantry {Amyd, Dark}](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Advance%20Wars%20Animation%20Ports/%5BBlack%20Hole%5D%20Infantry%20%7BAmyd,%20Dark%7D) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Advance%20Wars%20Animation%20Ports/%5BBlack%20Hole%5D%20Infantry%20%7BAmyd,%20Dark%7D)

| <b>Bow (Gun)</b><br/><img alt="Bow (Gun)" src="https://raw.githubusercontent.com/Klokinator/FE-Repo/main/Battle%20Animations/Advance%20Wars%20Animation%20Ports/%5BBlack%20Hole%5D%20Infantry%20%7BAmyd,%20Dark%7D/5.%20Bow%20(Gun)/Bow.gif"/> |
| :---: |

## Credits

- Sprites By {Amyd}

- Coding and Formatting by Dark. (Kurwa Dark!)

