# [\[FE9 Lord Custom\] \[M\] Ike Lord by ReykRS](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FLords%20-%20Vanilla%20and%20Custom%2F%5BFE9%20Lord%20Custom%5D%20%5BM%5D%20Ike%20Lord%20by%20ReykRS%2F1.%20Sword)

## Sword

| Still | Animation |
| :---: | :-------: |
| ![Sword still](./Sword_000.png) | ![Sword](./Sword.gif) |

## Credit

Animation by JPN.

Scripting by ReykRS, Enjin.

