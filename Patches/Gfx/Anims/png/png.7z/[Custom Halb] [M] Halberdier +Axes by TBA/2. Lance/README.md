# [\[Custom Halb\] \[M\] Halberdier +Axes by TBA](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FInfantry%20-%20(Lnc)%20Soldiers%2C%20Halberdiers%2F%5BCustom%20Halb%5D%20%5BM%5D%20Halberdier%20%2BAxes%20by%20TBA%2F2.%20Lance)

## Lance

| Still | Animation |
| :---: | :-------: |
| ![Lance still](./Lance_000.png) | ![Lance](./Lance.gif) |

## Credit

Base animation by TheBlindArcher. Further improvements added by Spud, MeatofJustice.

Lance by TheBlindArcher.

Axe Stab by Spud

Axe Swing by Spud and MeatOfJustice.

Handaxe by Spud.

Unarmed by TheBlindArcher.
